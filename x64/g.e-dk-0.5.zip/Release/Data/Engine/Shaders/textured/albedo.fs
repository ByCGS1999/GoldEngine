#version 330



void main()
{
        
}
Put in here the compiled engine executable (the one you're using on retail.)
If the assembly is targetting win32/x86 the engine must be compiled using win32/x86.
Same for x64.
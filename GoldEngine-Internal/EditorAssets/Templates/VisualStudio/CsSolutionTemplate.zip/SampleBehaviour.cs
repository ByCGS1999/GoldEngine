﻿using Engine.Internal.Components;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GoldAssembly_Cs
{
    public class SampleBehaviour : Engine.EngineObjects.Script
    {
        public SampleBehaviour(string name, Transform transform) : base(name, transform)
        {
        }
    }
}
